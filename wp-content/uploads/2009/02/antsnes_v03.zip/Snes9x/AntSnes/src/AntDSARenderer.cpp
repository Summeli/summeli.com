/* AntSnes
 *
 * Copyright (C) 2009 Summeli <summeli@summeli.fi>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

#include <w32std.h>
#include <e32cmn.h>
#include <coemain.h>
#include <bitstd.h>
#include <eikenv.h>
#include "gfx.h"

#include "AntDSARenderer.h"


TInt KOffSetHorizontalWIDE = 32;

TUint8 g_ScanLineSkipTable[240];
void (*bitmapBlit)(TUint8* aScreen, TUint8* aBitmap) = 0;

CAntDSARenderer::CAntDSARenderer( RWindow& aWindow, TScreenMode aScreenMode )
:iWindow(aWindow), iScreenMode( aScreenMode )
    {
    
    }

CAntDSARenderer* CAntDSARenderer::NewL( CWindowGc& aGc, RWindow& aWindow, TSize aScreenSize, TScreenMode aScreenMode )
{
	CAntDSARenderer* self = new (ELeave) CAntDSARenderer( aWindow, aScreenMode );
    
    CleanupStack::PushL( self );
    self->ConstructL( aGc, aScreenSize );
    CleanupStack::Pop( self );
    return self;    
}

void CAntDSARenderer::AbortNow(RDirectScreenAccess::TTerminationReasons aReason)
    {
     //g_DSA->Cancel(); 
    //no updates during this time
    iDSAReady = EFalse;
    }

void CAntDSARenderer::Restart(RDirectScreenAccess::TTerminationReasons aReason)
    {
    TRAPD(dsaErr, iDSA->StartL());
     if( dsaErr )
     	{
     	//err
     	iDSAReady = EFalse;
     	return;
     	}
    RRegion *dsa_region = 0;
    dsa_region = iDSA->DrawingRegion();
    iGc->SetClippingRegion( dsa_region );
    iGc->BitBlt(TPoint(0, 0), iBlackScreen);
    iDSA->ScreenDevice()->Update();
    iDSAReady = ETrue;
    }

void CAntDSARenderer::ConstructL(CWindowGc& aGc, TSize aScreenSize)
    {
    iSize = aScreenSize;
    CWsScreenDevice* device = static_cast<CWsScreenDevice*> (aGc.Device());
    RRegion *dsa_region = 0;
    	
    iDSA = CDirectScreenAccess::NewL( CCoeEnv::Static()->WsSession(), *device, iWindow, *this );
    TRAPD(dsaErr, iDSA->StartL());
    iGc = iDSA->Gc();
    
    dsa_region = iDSA->DrawingRegion();
    iGc->SetClippingRegion( dsa_region );
    iBitmap = new (ELeave) CFbsBitmap;
    iBitmap->Create( aScreenSize, EColor64K );
    
    iBlackScreen = new (ELeave) CFbsBitmap;
    iBlackScreen->Create( aScreenSize, EColor64K );
    
    iBlackScreen->LockHeap();
    iBitmap->LockHeap();
    TUint8 *bmpData = (TUint8 *) iBlackScreen->DataAddress();
    for( TInt i =0; i< aScreenSize.iWidth*aScreenSize.iHeight*2; i++)
     	{
     	*bmpData = 0x0;
     	bmpData++;
     	}
    
    bmpData = (TUint8 *) iBitmap->DataAddress();
    for( TInt i =0; i< aScreenSize.iWidth*aScreenSize.iHeight*2; i++)
    	{
    	*bmpData = 0x0;
    	bmpData++;
    	}
        
    iBlackScreen->UnlockHeap();
    iBitmap->UnlockHeap();
    
    }

CAntDSARenderer::~CAntDSARenderer()
    {
    if( iDSA )
    	{
    	iDSA->Cancel();
    	delete iDSA;
    	}
    delete iGc;
    delete iBitmap;
    delete iBlackScreen;
    }

void CAntDSARenderer::SetPal( TBool aPAL )
	{
	TSize landscape( 320, 240);
	TSize portrait( 240, 320);
	iPAL = aPAL;
	if( iSize == portrait )
		{
		if( iPAL )
			bitmapBlit = BlitPAL240x320;
		else
			bitmapBlit = BlitNTSC240x320;
		
		//Create skiptable
		for( TInt i=0; i<240; i++)
			{
			if(i % 15 )
				g_ScanLineSkipTable[i] = 0;
			else
				g_ScanLineSkipTable[i] = 1;
			}
		}
	if( iSize == landscape)
		{
		if (iScreenMode == ENGage)
			{
			//if ngage
			if( iPAL )
				bitmapBlit = BlitPAL320x240NGAGE;
			else
				bitmapBlit = BlitNTSC320x240NGAGE;
			}
		else
			{
			if( iPAL )
				bitmapBlit = BlitPAL320x240Normal;
			else
				bitmapBlit = BlitNTSC320x240Normal;
			}
		}
	}
void CAntDSARenderer::UpdateFPS( TInt aFPS )
	{   
	iFPS = aFPS;
	}

void CAntDSARenderer::DrawText(const TDesC& aText, TPoint aPoint )
{
	iGc->SetBrushColor(KRgbGreen);
	iGc->SetBrushStyle(CGraphicsContext::ESolidBrush);

	iGc->SetPenStyle(CGraphicsContext::ESolidPen);
	iGc->UseFont(CEikonEnv::Static()->DenseFont());
	iGc->DrawText(aText,aPoint);
	iGc->DiscardFont();
	
	iDSA->ScreenDevice()->Update();		

}

void CAntDSARenderer::PutS9xFrame()
    {
    if( !iDSAReady )
    	return;
    
    iBitmap->LockHeap();
    TUint8 *bmpData = (TUint8 *) iBitmap->DataAddress();
    TUint8* screen = GFX.Screen;

    //blit
    bitmapBlit( screen, bmpData );
    
    iBitmap->UnlockHeap();
    iGc->BitBlt(TPoint(0, 0), iBitmap);
#ifdef SHOW_FPS
    _LIT(KFps,"FPS: %d");
    TBuf<10> fpsBuf;
    TPoint pos(0,0);
    fpsBuf.Format( KFps, iFPS);
    iGc->UseFont(CEikonEnv::Static()->DenseFont());
    iGc->SetPenColor( KRgbWhite);
    iGc->DrawText( fpsBuf, pos);
#endif  
    iDSA->ScreenDevice()->Update();
    }

void BlitPAL320x240NGAGE( TUint8* aScreen, TUint8* aBitmap)
	{
	TUint16* bitmap = (TUint16*) aBitmap;
	TUint16* screen = (TUint16*) aScreen;
	bitmap += KOffSetHorizontalWIDE;
	screen += 256*239;
    	for( TInt i =0; i<239; i++ )
    		{
    		for( TInt j=0; j<256; j++)
    			{
     			*bitmap = *screen;
      			screen--;
      			bitmap++;
    			}
    		bitmap += KOffSetHorizontalWIDE*2;
    		}
	}

void BlitNTSC320x240NGAGE( TUint8* aScreen, TUint8* aBitmap)
	{
	TUint16* bitmap = (TUint16*) aBitmap;
	TUint16* screen = (TUint16*) aScreen;
	bitmap += 8*320;
	bitmap += KOffSetHorizontalWIDE;
	screen += 256*224;
  	for( TInt i =0; i<224; i++ )
  		{
  		for( TInt j=0; j<256; j++)
  			{
  			*bitmap = *screen;
  			screen--;
  			bitmap++;
  			}
  		bitmap += KOffSetHorizontalWIDE*2;
  		}
	}

void BlitPAL320x240Normal( TUint8* aScreen, TUint8* aBitmap)
	{
	TUint16* bitmap = (TUint16*) aBitmap;
	TUint16* screen = (TUint16*) aScreen;
	bitmap += KOffSetHorizontalWIDE;
    	for( TInt i =0; i<239; i++ )
    		{
    		for( TInt j=0; j<256; j++)
    			{
     			*bitmap = *screen;
      			screen++;
      			bitmap++;
    			}
    		bitmap += KOffSetHorizontalWIDE*2;
    		}
	}

void BlitNTSC320x240Normal( TUint8* aScreen, TUint8* aBitmap)
	{
	TUint16* bitmap = (TUint16*) aBitmap;
	TUint16* screen = (TUint16*) aScreen;
	bitmap += 8*320;
	bitmap += KOffSetHorizontalWIDE;
  	for( TInt i =0; i<224; i++ )
  		{
  		for( TInt j=0; j<256; j++)
  			{
  			*bitmap = *screen;
  			screen++;
  			bitmap++;
  			}
  		bitmap += KOffSetHorizontalWIDE*2;
  		}
	}
void BlitNTSC240x320( TUint8* aScreen, TUint8* aBitmap)
	{
	TUint16* bitmap = (TUint16*) aBitmap;
	TUint16* screen = (TUint16*) aScreen;
	bitmap += 48*240; //move to right postion
	TUint16 red;
	TUint16 green;
	TUint16 blue;
	TUint16 red2;
	TUint16 green2;
	TUint16 blue2;
	for( TInt i =0; i<224; i++ )
  		{
  		for( TInt j=0; j<240; j++)
  			{
  			if( g_ScanLineSkipTable[j] == 1)
  				{
  				red = *screen & 0x1F;
  				green = *screen & 0x7E0;
  				blue = *screen & 0xF800;
  				screen++;
  				red2 = *screen & 0x1F;
  				green2 = *screen & 0x7E0;
  				blue2 = *screen & 0xF800;
  				red = red + red2 >>1;
  				green = (green + green2 >> 1) & 0x7E0;
  				blue = (blue + blue2 >> 1) & 0xF800;
  				*bitmap = red + (green) + (blue);
  				bitmap++;
  				screen++;
  				}
  			else
  				{
  				*bitmap = *screen;
  				bitmap++;
  				screen++;
  				}
  			}
  		}
	}

void BlitPAL240x320( TUint8* aScreen, TUint8* aBitmap)
	{
	TUint16* bitmap = (TUint16*) aBitmap;
	TUint16* screen = (TUint16*) aScreen;
	bitmap += 40*240; //move to right postion
	TUint16 red;
	TUint16 green;
	TUint16 blue;
	TUint16 red2;
	TUint16 green2;
	TUint16 blue2;
	for( TInt i =0; i<239; i++ )
		{
		for( TInt j=0; j<240; j++)
			{
			if( g_ScanLineSkipTable[j] == 1)
				{
				red = *screen & 0x1F;
				green = *screen & 0x7E0;
				blue = *screen & 0xF800;
				screen++;
				red2 = *screen & 0x1F;
				green2 = *screen & 0x7E0;
				blue2 = *screen & 0xF800;
				red = red + red2 >>1;
				green = (green + green2 >> 1) & 0x7E0;
				blue = (blue + blue2 >> 1) & 0xF800;
				*bitmap = red + (green) + (blue);
				bitmap++;
				screen++;
				}
			else
				{
				*bitmap = *screen;
				bitmap++;
				screen++;
				}
			}
		}
	}
