/* AntSnes
 *
 * Copyright (C) 2009 Summeli <summeli@summeli.fi>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License as
 * published by the Free Software Foundation; either version 2 of
 * the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

// INCLUDE FILES
#include <avkon.hrh>
#include <aknmessagequerydialog.h>
#include <aknnotewrappers.h>
#include <stringloader.h>
#include <f32file.h>
#include <s32file.h>
#include <hlplch.h>
#include <aknwaitdialog.h> 

//Dialogs
#include <AknCommonDialogs.h> // For single function calls
#include <CAknFileSelectionDialog.h>

#include <AntSnes.rsg>

//#include "AntSnes.hlp.hrh"
#include "AntSnes.hrh"
#include "AntSnes.pan"
#include "AntSnesApplication.h"
#include "AntSnesAppUi.h"
#include "AntSnesContainer.h"
#include "AntKeyDialog.h"
namespace
{
_LIT( KFileName, "C:\\private\\E5712A80\\AntSnes.txt" );
#define KFILEPATHLENGHT 100
#define KAntSnesSettingsVersion 3 //the settings version
const TUid KAntSettings={0xE5712A80};

};

// ============================ MEMBER FUNCTIONS ===============================


// -----------------------------------------------------------------------------
// CAntSnesAppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void CAntSnesAppUi::ConstructL()
	{
	CDictionaryStore* prefs = Application()->OpenIniFileLC(CCoeEnv::Static()->FsSession()); 
	InternalizeL(*prefs);
	CleanupStack::PopAndDestroy();//close prefs
    
    if( iSettings.iScreenMode == EPortrait)
    	{
    	BaseConstructL(EAknEnableSkin | EAppOrientationPortrait);
    	iSettings.iScanKeyTable[0]= EStdKeyUpArrow;			
    	iSettings.iScanKeyTable[1]= EStdKeyDownArrow;
    	iSettings.iScanKeyTable[2]=EStdKeyLeftArrow;
    	iSettings.iScanKeyTable[3]= EStdKeyRightArrow;
    	                    	
    	}
    else if( iSettings.iScreenMode == ELandscape)
    	{
    	BaseConstructL( EAknEnableSkin | EAppOrientationLandscape);
    	iSettings.iScanKeyTable[0]= EStdKeyUpArrow;			
    	iSettings.iScanKeyTable[1]= EStdKeyDownArrow;
    	iSettings.iScanKeyTable[2]=EStdKeyLeftArrow;
    	iSettings.iScanKeyTable[3]= EStdKeyRightArrow;
    	}
    else if( iSettings.iScreenMode == ENGage)
    	{
    	BaseConstructL( EAknEnableSkin | EAppOrientationLandscape);
      	iSettings.iScanKeyTable[0]= EStdKeyDownArrow;			
        iSettings.iScanKeyTable[1]= EStdKeyUpArrow;
        iSettings.iScanKeyTable[2]=EStdKeyRightArrow;
        iSettings.iScanKeyTable[3]= EStdKeyLeftArrow;
    	}
	
    iAppContainer = new (ELeave) CAntSnesContainer;
    iAppContainer->ConstructL( ApplicationRect(), iSettings );
    AddToStackL( iAppContainer );
    
    //set generated itemlist
    iItemList = TAntSnesSettingItemListSettings::NewL();
    iItemList->SetEnumeratedTextPopup1(iSettings.iScreenMode);
    iItemList->SetEnumeratedTextPopup2(iSettings.iRenderer); 
    iResetRequired = EFalse;
    // Start in  fullscreen because of problem issue in 3.0 openGL 
    iFullScreen = 1;
	
    // series60 blocks simultaneous key presses by default
    // this game uses throttle and steering keys at the same time
    // and this line makes it possible
    SetKeyBlockMode( ENoKeyBlock );

    //Display menubar
    CEikonEnv::Static()->AppUiFactory()->MenuBar()->TryDisplayMenuBarL();
	}
// -----------------------------------------------------------------------------
// CAntSnesAppUi::CAntSnesAppUi()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
CAntSnesAppUi::CAntSnesAppUi()
	{
	// No implementation required
	}

// -----------------------------------------------------------------------------
// CAntSnesAppUi::~CAntSnesAppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
CAntSnesAppUi::~CAntSnesAppUi()
	{
	if ( iAppContainer )
		{
		RemoveFromStack( iAppContainer );
		delete iAppContainer;
		}
	
	if ( iSettingsList )
		{
		RemoveFromStack( iSettingsList );
		delete iSettingsList;
		delete iItemList;
		}
	
	delete iSettings.iROMPath;
	}

// -----------------------------------------------------------------------------
// CAntSnesAppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void CAntSnesAppUi::HandleCommandL(TInt aCommand)
	{
	iMenuOpen = EFalse;
	switch (aCommand)
		{	
		case ELoadRom:
			{
			DismissSettings();
			HBufC* buf = HBufC::NewLC(KFILEPATHLENGHT);
			TPtr ptr = buf->Des();
			TBool selected;
			/*if( iSettings.iROMPath )
				selected = AknCommonDialogs::RunSelectDlgLD(ptr, iSettings.iROMPath->Des(), R_MEMORY_SELECTION_DIALOG, R_LOAD_ROM_DIALOG);
			else*/
				selected = AknCommonDialogs::RunSelectDlgLD(ptr, R_MEMORY_SELECTION_DIALOG, R_LOAD_ROM_DIALOG);
	        if( selected )
	        	{
	        	//save the path
	        	if( iSettings.iROMPath )
	        		{
	        		delete iSettings.iROMPath;
	        		iSettings.iROMPath = NULL;
	        		}
	        	TParse parse;
	        	parse.Set(*buf, NULL, NULL); 
	        	iSettings.iROMPathLenght = parse.DriveAndPath().Length();
	        	iSettings.iROMPath = HBufC::NewL(iSettings.iROMPathLenght);
	        	TPtr romPtr = iSettings.iROMPath->Des();
	        	romPtr.Copy( parse.DriveAndPath() );
	        	
	        	//Load ROM
	        	iAppContainer->LoadROM( ptr );
	        	}
	        CleanupStack::PopAndDestroy(buf);
			}
			break;
		case ESaveState1:
		case ESaveState2:
		case ESaveState3:
		case ESaveState4:
		case ESaveState5:
			{
			TInt state = ESaveState1 - aCommand;
			iAppContainer->SaveStateL( state );
			}
			break;
			
		case ELoadState1:
		case ELoadState2:
		case ELoadState3:
		case ELoadState4:
		case ELoadState5:
			{
			TInt state = ELoadState1 - aCommand;
			iAppContainer->LoadStateL( state );
			}
			break;
		case EResetGame:
			{
			iAppContainer->ResetGame();
			}
			break;
		case EVideoSettings:
			{
			//run settings dialog
			RemoveFromStack(iAppContainer);
			DismissSettings();
		    iSettingsList = new (ELeave) CAntSnesSettingItemList( *iItemList, this );
		    iSettingsList->SetMopParent( this );
			iSettingsList->ConstructFromResourceL( R_ANT_SNES_SETTING_ITEM_LIST_ANT_SNES_SETTING_ITEM_LIST_2 );
			iSettingsList->ActivateL();
			iSettingsList->LoadSettingValuesL();
			iSettingsList->LoadSettingsL();
			AddToStackL( iSettingsList );
			}
			break;
		case EAntSnesKeyConfig:
			{
			//run keyconfig
			StartKeyConfigL();	
		    //Save Settings
		    SaveSettingsL( EFalse ); //no restart required
		    //update keyconfig
		    iAppContainer->UpdateRunTimeSettings( iSettings );
			}
			break;
		case ESettingsSaved:
			{
			SaveSettingsL( ETrue );
			}
			break;
		case EAbout:
			{

			CAknMessageQueryDialog* dlg = new (ELeave) CAknMessageQueryDialog();
			dlg->PrepareLC(R_ABOUT_QUERY_DIALOG);
			HBufC* title = iEikonEnv->AllocReadResourceLC(R_ABOUT_DIALOG_TITLE);
			dlg->QueryHeading()->SetTextL(*title);
			CleanupStack::PopAndDestroy(); //title
			HBufC* msg = iEikonEnv->AllocReadResourceLC(R_ABOUT_DIALOG_TEXT);
			dlg->SetMessageTextL(*msg);
			CleanupStack::PopAndDestroy(); //msg
			dlg->RunLD();
			}
			break;
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			DismissSettings();
			if( iResetRequired )
				{
				HBufC* textResource = StringLoader::LoadLC(R_RESTART_REQUIRED_NOTE);
				CAknNoteDialog* dialog = new (ELeave) CAknNoteDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
				dialog->SetTextL( *textResource );
				CleanupStack::PopAndDestroy(textResource); //text
				TInt key = dialog->ExecuteDlgLD( R_INFORM_USER );
				}
			SaveSettingsL( 0 );
			Exit();
			break;
			}		
		case EAknSoftkeyDone:
			//do nothing in here
			break;
		default:
			Panic(EAntSnesUi);
			break;
		}
	iAppContainer->Start();
	}

TKeyResponse CAntSnesAppUi::HandleKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
	{
	if( aKeyEvent.iScanCode == EStdKeyDevice1 && iMenuOpen )
		{
		//The menu is cancelled, continue emulation
		iAppContainer->Start();
		iMenuOpen = EFalse;
		}
	return EKeyWasNotConsumed;
	}

void CAntSnesAppUi::DynInitMenuPaneL( TInt aResourceId, CEikMenuPane* aMenuPane )
    {
    if( aResourceId == R_MENU )
    	{
    	iAppContainer->Pause();
    	iMenuOpen = ETrue;
    	}
    }


CArrayFix<TCoeHelpContext>* CAntSnesAppUi::HelpContextL() const
	{
#warning "Please see comment about help and UID3..."
	// Note: Help will not work if the application uid3 is not in the
	// protected range.  The default uid3 range for projects created
	// from this template (0xE0000000 - 0xEFFFFFFF) are not in the protected range so that they
	// can be self signed and installed on the device during testing.
	// Once you get your official uid3 from Symbian Ltd. and find/replace
	// all occurrences of uid3 in your project, the context help will
	// work. Alternatively, a patch now exists for the versions of 
	// HTML help compiler in SDKs and can be found here along with an FAQ:
	// http://www3.symbian.com/faq.nsf/AllByDate/E9DF3257FD565A658025733900805EA2?OpenDocument

	/*
	CArrayFixFlat<TCoeHelpContext>* array = new (ELeave) CArrayFixFlat<
			TCoeHelpContext> (1);
	CleanupStack::PushL(array);
	array->AppendL(TCoeHelpContext(KUidAntSnesApp, KGeneral_Information));
	CleanupStack::Pop(array);
	return array;*/
	}

void CAntSnesAppUi::SaveSettingsL( TBool aRestartRequired )
{
	//save settings 
	iSettings.iScreenMode = (TScreenMode) iItemList->EnumeratedTextPopup1();
	iSettings.iRenderer = (TScreenRenderer) iItemList->EnumeratedTextPopup2();
	CDictionaryStore* prefs = Application()->OpenIniFileLC(iEikonEnv->FsSession());
	ExternalizeL(*prefs);
	prefs->CommitL();
	CleanupStack::PopAndDestroy();//close prefs
	if( !iResetRequired )
		{
		iResetRequired = aRestartRequired;
		}
}


void CAntSnesAppUi::ExternalizeL(CDictionaryStore& aStore) 
{	
	RDictionaryWriteStream writeStream;
	writeStream.AssignLC(aStore, KAntSettings);
	writeStream.WriteInt32L(iSettings.iVersion);
	for(TInt i=0;i<12;i++)
		{
		writeStream.WriteInt32L(iSettings.iScanKeyTable[i]);
		}
	
	writeStream.WriteInt32L(iSettings.iScreenMode);
	writeStream.WriteInt32L( iSettings.iRenderer );
	writeStream.WriteInt32L(iSettings.iROMPathLenght);
	if( iSettings.iROMPathLenght )
		writeStream.WriteL(*iSettings.iROMPath);
	
	writeStream.CommitL();
	
	
	CleanupStack::PopAndDestroy();//writeStream
}

void CAntSnesAppUi::InternalizeL(const CDictionaryStore& aStore)
{
	if (!aStore.IsPresentL(KAntSettings))
		{
		SetDefaultSettings();
        return;
		}
	RDictionaryReadStream	readStream;
	readStream.OpenLC(aStore, KAntSettings);
	
	iSettings.iVersion = readStream.ReadInt32L();
	if( iSettings.iVersion != KAntSnesSettingsVersion )
		{
		//it was old version, use defaults intead
		SetDefaultSettings();
		CleanupStack::PopAndDestroy(); //readstream
		return;
		}
	
	for(TInt i=0;i<12;i++)
	{
	iSettings.iScanKeyTable[i] = readStream.ReadInt32L();
	}
	
	iSettings.iScreenMode = (TScreenMode) readStream.ReadInt32L();
	iSettings.iRenderer = (TScreenRenderer) readStream.ReadInt32L();
    
	iSettings.iROMPathLenght = readStream.ReadInt32L();
	if( iSettings.iROMPathLenght )
		{
		iSettings.iROMPath = HBufC::NewL(iSettings.iROMPathLenght);
		TPtr romPtr = iSettings.iROMPath->Des();
		readStream.ReadL(romPtr,iSettings.iROMPathLenght);
		}
	
	CleanupStack::PopAndDestroy(); //readstream
}

void CAntSnesAppUi::SetDefaultSettings()
	{
	//default settings
	iSettings.iScreenMode = EPortrait;
	iSettings.iRenderer = EDSA;
	iSettings.iVersion = KAntSnesSettingsVersion;
    iSettings.iScanKeyTable[4]= 49;
    iSettings.iScanKeyTable[5]= 50;
    iSettings.iScanKeyTable[6]= 51;
    iSettings.iScanKeyTable[7]= 52;
    iSettings.iScanKeyTable[8]= 0;
    iSettings.iScanKeyTable[9]= 0;
    iSettings.iScanKeyTable[10]= 0;
    iSettings.iScanKeyTable[11]= 0;
	
    iSettings.iROMPathLenght = 0;
    iSettings.iROMPath = NULL;
	}

void CAntSnesAppUi::StartKeyConfigL()
	{
	HBufC* textResource = NULL;
	CAntKeyDialog* dialog = NULL;
	//A button
	textResource = StringLoader::LoadLC(R_PRESS_A_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[4] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //X Button
	textResource = StringLoader::LoadLC(R_PRESS_X_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[5] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //Y Button
	textResource = StringLoader::LoadLC(R_PRESS_Y_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[6] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //B Button
	textResource = StringLoader::LoadLC(R_PRESS_B_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[7] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //Start Button
	textResource = StringLoader::LoadLC(R_PRESS_START_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[8] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //Select Button
	textResource = StringLoader::LoadLC(R_PRESS_SELECT_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[9] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //TL Button
	textResource = StringLoader::LoadLC(R_PRESS_TL_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[10] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
    //TR Button
	textResource = StringLoader::LoadLC(R_PRESS_TR_BUTTON);
	dialog = new (ELeave) CAntKeyDialog(CAknNoteDialog::ENoTone,CAknNoteDialog::ENoTimeout);
	iSettings.iScanKeyTable[11] = dialog->RunKeyDialogLD( *textResource);
    CleanupStack::PopAndDestroy(textResource);
    
	}

void CAntSnesAppUi::DismissSettings()
	{
	if( iSettingsList )
		{
		RemoveFromStack(iSettingsList);
		delete iSettingsList;
		iSettingsList = NULL;
		}
	}
// End of File
