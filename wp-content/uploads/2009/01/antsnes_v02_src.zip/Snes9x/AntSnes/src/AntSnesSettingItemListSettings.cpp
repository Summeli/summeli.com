/*
========================================================================
 Name        : AntSnesSettingItemListSettings.cpp
 Author      : 
 Copyright   : Your copyright notice
 Description : 
========================================================================
*/
/**
 *	Generated helper class which manages the settings contained 
 *	in 'AntSnesSettingItemList'.  Each CAknSettingItem maintains
 *	a reference to data in this class so that changes in the setting
 *	item list can be synchronized with this storage.
 */
 
// [[[ begin generated region: do not modify [Generated Includes]
#include <e32base.h>
#include <stringloader.h>
#include <barsread.h>
#include <AntSnes.rsg>
#include "AntSnesSettingItemListSettings.h"
// ]]] end generated region [Generated Includes]

/**
 * C/C++ constructor for settings data, cannot throw
 */
TAntSnesSettingItemListSettings::TAntSnesSettingItemListSettings()
	{
	}

/**
 * Two-phase constructor for settings data
 */
TAntSnesSettingItemListSettings* TAntSnesSettingItemListSettings::NewL()
	{
	TAntSnesSettingItemListSettings* data = new( ELeave ) TAntSnesSettingItemListSettings;
	CleanupStack::PushL( data );
	data->ConstructL();
	CleanupStack::Pop( data );
	return data;
	}
	
/**
 *	Second phase for initializing settings data
 */
void TAntSnesSettingItemListSettings::ConstructL()
	{
	// [[[ begin generated region: do not modify [Generated Initializers]
	SetEnumeratedTextPopup1( 1 );
	// ]]] end generated region [Generated Initializers]
	
	}
	
// [[[ begin generated region: do not modify [Generated Contents]
TInt& TAntSnesSettingItemListSettings::EnumeratedTextPopup1()
	{
	return iEnumeratedTextPopup1;
	}

void TAntSnesSettingItemListSettings::SetEnumeratedTextPopup1(const TInt& aValue)
	{
	iEnumeratedTextPopup1 = aValue;
	}

// ]]] end generated region [Generated Contents]

