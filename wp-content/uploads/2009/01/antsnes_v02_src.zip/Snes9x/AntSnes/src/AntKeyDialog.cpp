/*
 * AntKeyDialog.cpp
 *
 *  Created on: Jan 30, 2009
 *      Author: Administrator
 */

#include "AntKeydialog.h"
#include <AntSnes.rsg>
#include <stringloader.h>
#include <e32keys.h>
CAntKeyDialog ::CAntKeyDialog(const TTone aTone, const TTimeout aTimeout)
:CAknNoteDialog(aTone,aTimeout)
    {
    }

CAntKeyDialog::~CAntKeyDialog() 
{
}


TKeyResponse CAntKeyDialog::OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType)
{
    if( aType == EEventKeyDown)
        {
        //save the scancode
        if( aKeyEvent.iScanCode == EStdKeyDevice1 || aKeyEvent.iScanCode == 1)
        	{
        	//skip
        	iKeyScanCode = 0;
        	}
        else
        	iKeyScanCode = aKeyEvent.iScanCode;
        iWait->AsyncStop();
        StaticDeleteL(this);
        }

   return EKeyWasConsumed;
}

TInt CAntKeyDialog::RunKeyDialogLD( const TDesC& aText)
    {
    if( iWait )
    	{
    	delete iWait;
    	iWait = NULL;
    	}
    iWait = new (ELeave) CActiveSchedulerWait();
    CAknNoteDialog::SetTextL( aText );
    CAknNoteDialog::ExecuteDlgLD( R_INFORM_USER );
    iWait->Start();
    delete iWait;
    iWait = NULL;
    return iKeyScanCode;
    }
