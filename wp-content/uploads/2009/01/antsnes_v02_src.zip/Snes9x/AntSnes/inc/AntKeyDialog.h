/*
 * AntKeyDialog.h
 *
 *  Created on: Jan 30, 2009
 *      Author: Administrator
 */

#ifndef ANTKEYDIALOG_H_
#define ANTKEYDIALOG_H_

#include <e32std.h>
#include <e32base.h>
#include <AknGlobalNote.h>
#include <aknnotedialog.h> 

/**
* Dialog class for keyconfig. 
*/
class CAntKeyDialog : public CAknNoteDialog
{
public:
	CAntKeyDialog(const TTone aTone, const TTimeout aTimeout);
    
    ~CAntKeyDialog();
   
    TInt RunKeyDialogLD( const TDesC& aText);
  

private:
    TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
    TInt iKeyScanCode;
    CActiveSchedulerWait* iWait;
};

#endif /* ANTKEYDIALOG_H_ */
