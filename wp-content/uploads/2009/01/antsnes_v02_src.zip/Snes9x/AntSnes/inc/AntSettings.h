/*
 * AntSettings.h
 *
 *  Created on: 23.1.2009
 *      Author: Antti Pohjola
 */

#ifndef ANTSETTINGS_H_
#define ANTSETTINGS_H_

#include "e32std.h"

enum TScreenMode
{
	EPortrait = 1,
	ELandscape,
	ENGage
};
struct TAntSettings
{
	TInt iVersion;
	//matches to the snes-keys
	TUint16 iScanKeyTable[12];
	TScreenMode iScreenMode;
	//TUint16 KAntKeyTable[12]={SNES_UP_MASK,SNES_DOWN_MASK,SNES_LEFT_MASK,SNES_RIGHT_MASK,SNES_A_MASK,SNES_X_MASK,SNES_Y_MASK,SNES_B_MASK,SNES_START_MASK,SNES_SELECT_MASK,SNES_TL_MASK,SNES_TR_MASK};
	
};

#endif /* ANTSETTINGS_H_ */
