/*
========================================================================
 Name        : AntSnesSettingItemListSettings.h
 Author      : 
 Copyright   : Your copyright notice
 Description : 
========================================================================
*/
#ifndef ANTSNESSETTINGITEMLISTSETTINGS_H
#define ANTSNESSETTINGITEMLISTSETTINGS_H
			
// [[[ begin generated region: do not modify [Generated Includes]
#include <e32std.h>
// ]]] end generated region [Generated Includes]

// [[[ begin generated region: do not modify [Generated Constants]
// ]]] end generated region [Generated Constants]

/**
 * @class	TAntSnesSettingItemListSettings AntSnesSettingItemListSettings.h
 */
class TAntSnesSettingItemListSettings
	{
public:
	// construct and destroy
	static TAntSnesSettingItemListSettings* NewL();
	void ConstructL();
		
private:
	// constructor
	TAntSnesSettingItemListSettings();
	// [[[ begin generated region: do not modify [Generated Accessors]
public:
	TInt& EnumeratedTextPopup1();
	void SetEnumeratedTextPopup1(const TInt& aValue);
	// ]]] end generated region [Generated Accessors]
	
	// [[[ begin generated region: do not modify [Generated Members]
protected:
	TInt iEnumeratedTextPopup1;
	// ]]] end generated region [Generated Members]
	
	};
#endif // ANTSNESSETTINGITEMLISTSETTINGS_H
