/*******************************************************************
 *
 *	File:		Dialogs.cpp
 *
 *	Author:		Peter van Sebille (peter@yipton.net)
 *
 *	(c) Copyright 2003, Peter van Sebille
 *	All Rights Reserved
 *
 *******************************************************************/

#ifndef __VERSION_H
#define __VERSION_H

#define KMajorVersionNumber 0
#define KMinorVersionNumber 40
#define KBuildNumber 0

#endif			/* __VERSION_H */
