

License mess
------------


Snes9x is under it's own license (license_snes9x.txt).

The Snes9x ASM optimization and modifications are under GPL made by notaz.

The AntSnes is also under GPL v2. 


Contact
-------
My e-mail: summeli@summeli.fi
